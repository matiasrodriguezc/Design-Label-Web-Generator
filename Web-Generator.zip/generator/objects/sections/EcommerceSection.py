from generator.objects.sections.Section import Section


class EcommerceSection(Section):

    def __init__(self):
        super().__init__("e-commerce", "e-commerce")