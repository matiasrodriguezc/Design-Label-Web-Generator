export const SECTIONS = [
  { name: "Template", component: "Template" },
];