 export const FOOTER_LINKS = [
    {
        title: "Navegacion",
        links: [
        { label: "Services", href: "/" },
        { label: "Portfolio", href: "/" },
        { label: "Contact", href: "/" },
        { label: "About us", href: "/" },
        ],
    },
    ];

    export const SOCIALS = {
    title: "Social",
    data: [
        { image: "/facebook.svg", href: "https://www.facebook.com" },
        { image: "/instagram.svg", href: "https://www.instagram.com" },
        { image: "/x.svg", href: "https://twitter.com" },
    ],
    };
    