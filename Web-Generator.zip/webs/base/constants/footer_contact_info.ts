export const FOOTER_CONTACT_INFO = {
    title: "Contactanos",
    links: [
    { label: "Email", value: "contactDesignLabel@gmail.com" },
    { label: "Ubicacion", value: "Pinto 401 Argentina, Tandil" },
],
};